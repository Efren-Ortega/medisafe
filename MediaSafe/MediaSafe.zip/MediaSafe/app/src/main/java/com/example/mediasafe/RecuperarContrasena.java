package com.example.mediasafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RecuperarContrasena extends AppCompatActivity {

    private Button btnRestore;
    private EditText txtCode, edCorreo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_contrasena);

        btnRestore =(Button) findViewById(R.id.btnRestore);
        txtCode = (EditText) findViewById(R.id.et_codigo);
        edCorreo = (EditText) findViewById(R.id.et_correo);

        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(btnRestore.getText().equals("RECUPERAR CONTRASEÑA")){
                    //Toast.makeText(getApplicationContext(), "Ingrese su Correo", Toast.LENGTH_SHORT).show();

                }else{
                    if(edCorreo.getText().length() == 0){
                        Toast.makeText(getApplicationContext(), "Ingrese su Correo", Toast.LENGTH_SHORT).show();
                    }else{
                        btnRestore.setText("RECUPERAR CONTRASEÑA");
                        txtCode.setVisibility(view.VISIBLE);
                    }
                }

            }
        });

    }
}